/* Header scroll states: top → glass bar → compact pill while scrolling */
(function () {
  var header = document.getElementById('siteHeader');
  var idle;
  function onScroll() {
    var scrolled = window.scrollY > 32;
    header.classList.toggle('is-scrolled', scrolled);
    if (document.documentElement.getAttribute('data-motion') === 'reduce') return;
    if (scrolled) {
      header.classList.add('is-pill');
      clearTimeout(idle);
      idle = setTimeout(function () { header.classList.remove('is-pill'); }, 340);
    }
  }
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();
})();

/* Job filtering */
(function () {
  var q = document.getElementById('q');
  var dept = document.getElementById('dept');
  var office = document.getElementById('office');
  var count = document.getElementById('count');
  var empty = document.getElementById('empty');
  var jobs = Array.prototype.slice.call(document.querySelectorAll('.job'));

  function apply() {
    var term = q.value.trim().toLowerCase();
    var d = dept.value;
    var o = office.value;
    var shown = 0;
    jobs.forEach(function (el) {
      var ok = (!d || el.dataset.dept === d) &&
               (!o || el.dataset.offices.split('|').indexOf(o) > -1) &&
               (!term || el.dataset.search.indexOf(term) > -1);
      el.hidden = !ok;
      if (ok) shown++;
    });
    count.textContent = shown;
    empty.hidden = shown !== 0;
  }
  [q, dept, office].forEach(function (el) { el.addEventListener('input', apply); });
})();

/* Reduce motion — WCAG 2.2.2 pause mechanism */
(function () {
  var box = document.getElementById('reduceMotion');
  var stored = null;
  try { stored = localStorage.getItem('tph-motion'); } catch (e) {}
  var reduce = stored ? stored === 'reduce'
    : window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  function set(v) {
    document.documentElement.setAttribute('data-motion', v ? 'reduce' : 'full');
    box.checked = v;
    try { localStorage.setItem('tph-motion', v ? 'reduce' : 'full'); } catch (e) {}
  }
  set(reduce);
  box.addEventListener('change', function (e) { set(e.target.checked); });
})();

const API_URL =
  "https://boards-api.greenhouse.io/v1/boards/thepharmacyhub/jobs?content=true";

const jobList = document.getElementById("jobList");
const deptSelect = document.getElementById("dept");
const officeSelect = document.getElementById("office");
const searchInput = document.getElementById("q");
const count = document.getElementById("count");
const empty = document.getElementById("empty");
const openRoles = document.getElementById("openRoles");
const totalLocations = document.getElementById("totalLocations");

let jobs = [];

async function loadJobs() {
    try {
        const res = await fetch(API_URL);
        const data = await res.json();
		//console.log(data.jobs[0]);

jobs = (data.jobs || []).map(job => ({
    ...job,
    isNew: isRecent(job.first_published || job.updated_at)
}));		
   const uniqueLocations = [...new Set(jobs.map(job => job.location?.name))];

       // console.log("Unique Locations:");
       // console.log(uniqueLocations);
        // Update Open Roles
        if (openRoles) {
            openRoles.textContent = jobs.length;
        }

        // Update Total Locations
// Update Total Locations
if (totalLocations) {

    const locations = new Set();

    jobs.forEach(job => {

        let location = (job.location?.name || "")
            .trim()
            .replace(/\s+/g, " ")
            .replace(/,\s*fl$/i, "")
            .replace(/,\s*florida$/i, "")
            .replace(/,\s*united states$/i, "");

        location.split("&").forEach(part => {

            part = part.trim();

            if (part) {
                locations.add(part);
            }

        });

    });

   // console.log([...locations]); // Check final unique locations

    totalLocations.textContent = locations.size;
}

        populateDepartments();
        populateOffices();
        renderJobs(jobs);

    } catch (err) {
        console.error("Error loading jobs:", err);
    }
}

function populateDepartments() {

    deptSelect.innerHTML = `<option value="">All Departments</option>`;

    const departments = [
        ...new Set(
            jobs.flatMap(job =>
                (job.departments || []).map(dep => dep.name)
            )
        )
    ].sort();

    departments.forEach(dep => {

        const option = document.createElement("option");
        option.value = dep;
        option.textContent = dep;

        deptSelect.appendChild(option);

    });

}

function populateOffices() {

    officeSelect.innerHTML = `<option value="">All Offices</option>`;

    const offices = [
        ...new Set(
            jobs.flatMap(job =>
                (job.offices || []).map(office => office.name)
            )
        )
    ].sort();

    offices.forEach(office => {

        const option = document.createElement("option");
        option.value = office;
        option.textContent = office;

        officeSelect.appendChild(option);

    });

}

function renderJobs(list) {

    jobList.innerHTML = "";

    count.textContent = list.length;

    // No jobs found
    if (list.length === 0) {

        empty.hidden = false;
        return; // Yahin function stop ho jayega

    }

    // Jobs found
    empty.hidden = true;

    list.forEach(job => {

        const department =
            (job.departments || []).map(d => d.name).join(", ");

        const location =
            job.location?.name || "";

        jobList.insertAdjacentHTML("beforeend", `
<a class="job" href="${job.absolute_url}" target="_blank">

    <span class="job-mark">
        <img src="assets/logo-shell-dark.png" alt="">
    </span>

    <span class="job-main">

        <span class="job-row">

            <span>

                <h3>${job.title}</h3>

<span class="chips">
    <span class="chip chip-dept">${department}</span>
    <span class="chip chip-onsite">On-site</span>
    ${job.isNew ? '<span class="chip chip-new">Recently posted</span>' : ''}
</span>

            </span>

            <span class="job-meta">

                <span class="job-loc">${location}</span>

                <span class="btn-apply">
                    Apply
                </span>

            </span>

        </span>

    </span>

</a>
        `);

    });

}

function filterJobs() {

   const keyword = normalizeText(searchInput.value);
const keywordWords = keyword.split(" ").filter(Boolean);

    const selectedDepartment = deptSelect.value;
    const selectedOffice = officeSelect.value;

    const filtered = jobs.filter(job => {

        const departments =
            (job.departments || []).map(d => d.name);

        const offices =
            (job.offices || []).map(o => o.name);

        const parser = document.createElement("div");
        parser.innerHTML = job.content || "";

        const decodedContent =
            parser.textContent || parser.innerText || "";

       const locationText = normalizeText(
    job.location?.name || ""
);
        const departmentText =
            departments.join(" ");

        const officeText =
            offices.join(" ");

const searchData = normalizeText([
    job.title,
    //locationText,
    //departmentText,
    //officeText,
	//job.content
	
].join(" "));
const matchesKeyword =
    keywordWords.length === 0 ||
    keywordWords.every(word => searchData.includes(word));

        const matchesDepartment =
            !selectedDepartment ||
            departments.includes(selectedDepartment);

        const matchesOffice =
            !selectedOffice ||
            offices.includes(selectedOffice);

        return (
            matchesKeyword &&
            matchesDepartment &&
            matchesOffice
        );

    });

    renderJobs(filtered);

}

searchInput.addEventListener("input", filterJobs);
deptSelect.addEventListener("change", filterJobs);
officeSelect.addEventListener("change", filterJobs);

loadJobs();
function normalizeText(text) {
    return (text || "")
        .toLowerCase()
        .replace(/<[^>]*>/g, " ")
        .replace(/[^\w\s]/g, " ")
        .replace(/\s+/g, " ")
        .trim();
}
function isRecent(date) {
    if (!date) return false;

    const published = new Date(date);
    const days = (Date.now() - published.getTime()) / 86400000;

    return days <= 30;
}